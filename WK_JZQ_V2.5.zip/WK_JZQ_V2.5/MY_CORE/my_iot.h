


#ifndef __MY_IOT_H
#define __MY_IOT_H
#include "includes.h"




void my_iot (void *t);



//IOT��ʱ����ʱ�ж�
void IOT_Hander(void);



#endif




















