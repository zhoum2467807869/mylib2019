#include "Encoder.h"




extern gv_InitTypeDef *gv_p;




/*******************************************************************************
* Function Name  : ScanKey
* Description    : Scan the buttons pressed.
* Input          : Called every 5ms
* Output         : The key counters are updated
* Return         : None
*******************************************************************************/
void ScanKey(void)
{
	static uint8_t button_released=0;		//0 -- button is still being pressed
//******* KNOB_PUSHKEY -No auto repeat **********************************
	if (HAL_GPIO_ReadPin(ENCODER_SW_GPIO_Port,ENCODER_SW_Pin)==0)
    {

      if ((gv_p->u16_Debounce_CNT>=DEBOUNCE_TIME_ENCODER)&&button_released)
      {
        gv_p->u16_EncoderFlags|=ENCODER_HAVEKEY;    
        gv_p->u16_EncoderFlags|=ENCODER_PUSHKEY;
		button_released=0;
		  
      }
	}
	else 
	{

		gv_p->u16_Debounce_CNT=0;
		button_released=1;
	}
			
	}
		


void Encoder_Scan(void)
{
/***************************************************************
 To combine the A B phase bits together 0x0000ABab
 00xx, 11xx are valid combination; 01xx, 10xx are not valid  
	to avoid 2 detections per dent, only use 00xx for rotation detection.
 States Value: 0: no rotation or invalid; 1: Forward; 2: Backward 
	Encoder Bounce ~0.1ms
***************************************************************/  
	
	#define CW              1
	#define CCW             2
//  const uint8_t ENCODER_STATUS[] = {0,CCW,CW,0,0,0,0,0,0,0,0,0,0,CW,CCW,0};
	const uint8_t ENCODER_STATUS[] = {0,CCW,CW,0,0,0,0,0,0,0,0,0,0,0,0,0}; //To only allow one detection per dent
	static uint8_t old_AB = 0, new_AB=0;
	static uint8_t encoder_key;
	new_AB = (HAL_GPIO_ReadPin(ENCODER_A_GPIO_Port,ENCODER_A_Pin)<<1)|
						(HAL_GPIO_ReadPin(ENCODER_B_GPIO_Port,ENCODER_B_Pin));
	encoder_key =(old_AB <<2)|new_AB;
	if ( ENCODER_STATUS[( encoder_key & 0x0f )] ==CW)
    {

		gv_p->u16_EncoderFlags|=ENCODER_HAVEKEY;    
		gv_p->u16_EncoderFlags|=ENCODER_CWKEY;
	}
	else if ( ENCODER_STATUS[( encoder_key & 0x0f )] ==CCW)
    {
		gv_p->u16_EncoderFlags|=ENCODER_HAVEKEY;    
		gv_p->u16_EncoderFlags|=ENCODER_CCWKEY;
	}
	old_AB = new_AB;                  //remember previous state
}

/*******************************************************************************
* Function Name  : Encoder_Push_Process, Encoder_Forward_Process & Encoder_Backword_Process
* Description    : To process the push action. This action may be initiated by 
* the LCD touch or from the PC command.
* Input          : Encoder_Flags, Flags may be set by various routines.
* Output         : LCD upadated and related events trigered
* Return         : None
*******************************************************************************/
void Encoder_Push_Process(void)
{

	
/* -- TO USE ENCODER TO RUN TMS */
	if (gv_p->u16_SystemFlags&fTMS_TEST_ON)
	{
		gv_p->u16_SystemFlags&=~fTMS_TEST_ON;
		HAL_GPIO_WritePin(LED1_GPIO_Port,LED1_Pin,GPIO_PIN_SET);	//turn off LED1

	}	
	else
	{
		gv_p->u16_SystemFlags|=fTMS_TEST_ON;
		HAL_GPIO_WritePin(LED1_GPIO_Port,LED1_Pin,GPIO_PIN_RESET);	//turn on LED1	
		
	}
//--------------------------------------------------------------------------------------
	gv_p->u16_EncoderFlags&=~ENCODER_PUSHKEY;	
	
}

void Encoder_Forward_Process(void)
{
/* -- TO USE ENCODER TO RUN TMS - Increase power*/


	


//--------------------------------------------------------------------------------------
  gv_p->u16_EncoderFlags&=~ENCODER_CWKEY;
}

void Encoder_Backword_Process(void)
{
/* -- TO USE ENCODER TO RUN TMS - Decrease power*/
//	if ((gv_p->u16_SystemFlags&fTMS_TEST_ON)==0)
//	{
//		if (gv_p->u16_TMS_power>1)
//		{
//			gv_p->u16_TMS_power-=1;
//			HAL_GPIO_TogglePin(LED2_GPIO_Port,LED2_Pin);
//			TMS_power_adjust();
//		}
//	}
////--------------------------------------------------------------------------------------
//	dw_p->u8_Dwin_Dis_Page++;
//	if(button_UP==0&&dw_p->u8_Dwin_Dis_Page==2)
//	{
//		IntyAdd();
//	}
//	
//	if(dw_p->u8_Dwin_Dis_Page>9)dw_p->u8_Dwin_Dis_Page=1;
//	if(button_UP==1)
//	{
//		DWIN_PictureShow(dw_p->u8_Dwin_Dis_Page>6?1:dw_p->u8_Dwin_Dis_Page);
//		Beep(50);	
//	}

  gv_p->u16_EncoderFlags&=~ENCODER_CCWKEY;

}


/*******************************************************************************
* Function Name  : Encoder_Event_Process
* Description    : To process the encoder action. The source may also be from PC or LCD
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

void Encoder_Event_Process(void)
{
  gv_p->u16_EncoderFlags&=~ENCODER_HAVEKEY; 
	
	 if (gv_p->u16_EncoderFlags & ENCODER_PUSHKEY)
     {
       Encoder_Push_Process();
     }	
     if (gv_p->u16_EncoderFlags & ENCODER_CWKEY)
     {
       Encoder_Forward_Process();
     }	
     if (gv_p->u16_EncoderFlags & ENCODER_CCWKEY)
     {
       Encoder_Backword_Process();
     }	
}










