/******************** (C) COPYRIGHT 2013 DCOLOUR ********************
* File Name          : readme.txt
* Author             : DCOLOUR
* Version            : V1.1.1
* Date               : 04/10/2013
********************************************************************************
��REALVIEW 4.0���ϰ汾�򿪴򿪹��� RVMDK/DCDEM7.uvproj

******************* (C) COPYRIGHT 2010 DCOLOUR *****END OF FILE******
