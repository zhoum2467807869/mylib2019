#ifndef _HW_CONFIG_H
#define _HW_CONFIG_H

#include "stm32f10x.h"
#define	LEDRCC		RCC_APB2Periph_GPIOC
#define	LED_Port	GPIOC
#define	R_LED			GPIO_Pin_3
#define	G_LED			GPIO_Pin_4
#define	B_LED			GPIO_Pin_5

//���κ꣬��������������һ��ʹ��
#define LED1(a)	if (a)	\
					GPIO_SetBits(LED_Port,R_LED);	\
					else		\
					GPIO_ResetBits(LED_Port,R_LED)
#define LED2(a)	if (a)	\
					GPIO_SetBits(LED_Port,G_LED);	\
					else		\
					GPIO_ResetBits(LED_Port,G_LED)
#define LED3(a)	if (a)	\
					GPIO_SetBits(LED_Port,B_LED);	\
					else		\
					GPIO_ResetBits(LED_Port,B_LED)					
void Set_System(void);
void Interrupts_Config(void);
void TIMER_Config(void);
void LED_GPIO_Config(void);
					
#endif
