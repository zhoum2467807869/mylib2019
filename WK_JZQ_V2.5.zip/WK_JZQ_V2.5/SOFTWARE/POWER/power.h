

#ifndef __POWER_H
#define __POWER_H


#include "includes.h"



		//ϵͳ����
void SysPowerOn (void);

		//ϵͳ�ػ�
void SysPowerOff (void);


#endif









