#include "hmi_driver.h"

#define TX_8(P1) SEND_DATA((P1)&0xFF)  //���͵����ֽ�-SendChar();��ײ�ĺ���;

#define TX_8N(P,N) SendNU8((uint8 *)P,N)  //����N���ֽ�

#define TX_16(P1) TX_8((P1)>>8);TX_8(P1)  //����16λ����

#define TX_16N(P,N) SendNU16((uint16 *)P,N)  //����N��16λ����

#define TX_32(P1) TX_16((P1)>>16);TX_16((P1)&0xFFFF)  //����32λ����

#if(CRC16_ENABLE)

static uint16 _crc16 = 0xffff;
static void AddCRC16(uint8 *buffer,uint16 n,uint16 *pcrc)
{
    uint16 i,j,carry_flag,a;

    for (i=0; i<n; i++)
    {
        *pcrc=*pcrc^buffer[i];
        for (j=0; j<8; j++)
        {
            a=*pcrc;
            carry_flag=a&0x0001;
            *pcrc=*pcrc>>1;
            if (carry_flag==1)
                *pcrc=*pcrc^0xa001;
        }
    }
}

uint16 CheckCRC16(uint8 *buffer,uint16 n)
{
    uint16 crc0 = 0x0;
    uint16 crc1 = 0xffff;

    if(n>=2)
    {
        crc0 = ((buffer[n-2]<<8)|buffer[n-1]);
        AddCRC16(buffer,n-2,&crc1);
    }

    return (crc0==crc1);
}

void SEND_DATA(uint8 c)//��CRCУ��ĺ���;
{
    AddCRC16(&c,1,&_crc16);
    SendChar(c);
}

void BEGIN_CMD()
{
    TX_8(0XEE);
    _crc16 = 0XFFFF;//��ʼ����CRC16
}

void END_CMD()
{
    uint16 crc16 = _crc16;
    TX_16(crc16);//����CRC16
    TX_32(0XFFFCFFFF);
}

#else//NO CRC16

#define SEND_DATA(P) SendChar(P) //��ײ㺯��;
#define BEGIN_CMD() TX_8(0X5A)
#define END_CMD() TX_32(0XFFFCFFFF)

#endif

void DelayMS(unsigned int n)
{
    int i,j;
    for(i = n; i>0; i--)
        for(j=1000; j>0; j--) ;
}
//-------------�����ַ���(��ά����)----------------------------
void SendStrings(uchar *str)
{
    while(*str)
    {
        TX_8(*str);
        str++;
    }
}
//--------------����N��8λ��(һά����)---------------------------
void SendNU8(uint8 *pData,uint16 nDataLen)
{
    uint16 i = 0;
    for (; i<nDataLen; ++i)
    {
        TX_8(pData[i]);
    }
}
#if 1
uchar PM2_5[]= {0XFF,0X01,0X86,0X00,0X00,0X00,0X00,0X00,0X79};
void Send_PM2_5(void)
{
    SendNU8(PM2_5,9);
}
#endif
//--------------����N��16λ��(һά����)---------------------------
void SendNU16(uint16 *pData,uint16 nDataLen)
{
    uint16 i = 0;
    for (; i<nDataLen; ++i)
    {
        TX_16(pData[i]);
    }
}
//-----------------------------------------
void SetScreen(uint16 screen_id)
{
    BEGIN_CMD();
    TX_8(0xA5);
    TX_8(0x07);
    TX_8(0x82);
    TX_8(0x00);
    TX_8(0x84);
    TX_8(0x5A);
    TX_8(0x01);
    TX_16(screen_id);
}
void ShowRecSerValue(uint8 cmd,uint16 control_id,uint16 str)
{
    BEGIN_CMD();
    TX_8(0xA5);
    TX_8(0x05);
    TX_8(cmd);
    TX_16(control_id);
    TX_16(str);
}
void ShowRecDateAndProductValue(uint8 cmd,uint16 control_id,uint32 str)
{
    BEGIN_CMD();
    TX_8(0xA5);
    TX_8(0x07);
    TX_8(cmd);
    TX_16(control_id);
    TX_32(str);
}
/*!
 *  \brief ��ȡ���ò�������Ĵ�������
 */
void	ReadSetKeyReg(uint8 cmd,uint16 address,u8 len)
{
    BEGIN_CMD();
    TX_8(0xA5);
    TX_8(0x04);
    TX_8(cmd);
    TX_16(address);
    TX_8(len);
}
void	ReadSetParReg(uint8 cmd,uint16 address,u8 len)
{
    BEGIN_CMD();
    TX_8(0xA5);
    TX_8(0x04);
    TX_8(cmd);
    TX_16(address);
    TX_8(len);
}
/*!
 *  \brief ������ò�������Ĵ�������
 */
void	CLRsetKeyReg(uint8 cmd,uint16 address,u32 data)
{
    BEGIN_CMD();
    TX_8(0xA5);
    TX_8(0x07);
    TX_8(cmd);
    TX_16(address);
    TX_32(data);
}
/*!
 *  \brief ��������״̬�Ĵ���
 */
void	SetRunStateReg(uint8 cmd,uint16 address,u16 data)
{
    BEGIN_CMD();
    TX_8(0xA5);
    TX_8(0x05);
    TX_8(cmd);
    TX_16(address);
    TX_16(data);
}
void	SetWarningStateReg(uint8 cmd,uint16 address,u16 data)
{
    BEGIN_CMD();
    TX_8(0xA5);
    TX_8(0x05);
    TX_8(cmd);
    TX_16(address);
    TX_16(data);
}










