#ifndef __ENCODER_H__
#define __ENCODER_H__

#include "stm32f1xx_hal.h"
#include "main.h"

#define	ENCODER_HAVEKEY	0x01
#define	ENCODER_CWKEY	0x02
#define	ENCODER_CCWKEY	0x04
#define	ENCODER_PUSHKEY	0x08
#define	DEBOUNCE_TIME_ENCODER	3	//x*5ms Encoder push debounce and delay	
#define	TMS_BREAK_TIMEOUT		5000	//wait for 5S after TMS stopped to start discharge HV


#define	fTMS_TEST_ON	0x8000					

void ScanKey(void);
void Encoder_Scan(void);
void Encoder_Event_Process(void);

#endif





