
#include "os_mem.h"
#include "malloc.h"



void os_mem_init (void)
{
	mem_init( );
}




