#ifndef __KEY_H
#define	__KEY_H

#include "stm32f10x.h"
 /*******
 *�������±���
 KEY_ON 0
 KEY_OFF 1
 ********/
#define KEY_ON	0
#define KEY_OFF	1

#define	keyRCC	RCC_APB2Periph_GPIOE
#define	keyPort	GPIOE
#define	keyPin5	GPIO_Pin_5
#define	keyPin6	GPIO_Pin_6
void Key_GPIO_Config(void);
u8 Key_Scan(GPIO_TypeDef* GPIOx,u16 GPIO_Pin);

#endif /* __LED_H */

