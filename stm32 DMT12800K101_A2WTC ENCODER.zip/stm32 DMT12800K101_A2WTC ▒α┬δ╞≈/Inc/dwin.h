#ifndef DWIN_H
#define DWIN_H


#include "stm32f1xx_hal.h"


#define CRC16 		1
#define noCRC16 	0

extern uint8_t Usart2_TBuff[100];
extern uint8_t Usart2_RBuff[100];



void DWIN_ICO_display(uint16_t addr, int pos);
void DWIN_PictureShow (uint16_t data);
void DWIN_ShowString(uint16_t addr,uint8_t *str);	
void DWIN_Init(void);
void DWIN_ShowNum(uint16_t addr, int num);
void DWIN_ReadRTC(void);
void DWIN_SetRTC(uint8_t year , uint8_t month , uint8_t date , uint8_t hour , uint8_t min , uint8_t second);
void DWIN_Page_pos(void);



uint16_t Get_CRC16(__IO uint8_t *p_frame,uint8_t len_in_byte) ;




#endif



