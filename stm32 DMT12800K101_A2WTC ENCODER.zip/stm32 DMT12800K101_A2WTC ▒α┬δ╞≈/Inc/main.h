/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
/* USER CODE BEGIN Private defines */
#define SCR_TRIGER_Pin GPIO_PIN_0
#define SCR_TRIGER_GPIO_Port GPIOC
#define HV_DISCHAGE_Pin GPIO_PIN_1
#define HV_DISCHAGE_GPIO_Port GPIOC
#define NTC_1_Pin GPIO_PIN_0
#define NTC_1_GPIO_Port GPIOA
#define NTC_2_Pin GPIO_PIN_1
#define NTC_2_GPIO_Port GPIOA
#define HVCAP_S_Pin GPIO_PIN_2
#define HVCAP_S_GPIO_Port GPIOA
#define HVDC_S_Pin GPIO_PIN_3
#define HVDC_S_GPIO_Port GPIOA
#define CAP_DAC_Pin GPIO_PIN_4
#define CAP_DAC_GPIO_Port GPIOA
#define DC_DAC_Pin GPIO_PIN_5
#define DC_DAC_GPIO_Port GPIOA
#define EMERG_EXTI6_Pin GPIO_PIN_6
#define EMERG_EXTI6_GPIO_Port GPIOA
#define RESERVED_IO_Pin GPIO_PIN_7
#define RESERVED_IO_GPIO_Port GPIOA
#define COM4G_TX_Pin GPIO_PIN_8
#define COM4G_TX_GPIO_Port GPIOD
#define COM4G_RX_Pin GPIO_PIN_9
#define COM4G_RX_GPIO_Port GPIOD
#define RSTN_4G_Pin GPIO_PIN_10
#define RSTN_4G_GPIO_Port GPIOD
#define PWR_DWN_4G_Pin GPIO_PIN_11
#define PWR_DWN_4G_GPIO_Port GPIOD
#define RELAY_CTRL_Pin GPIO_PIN_8
#define RELAY_CTRL_GPIO_Port GPIOA
#define PC_TX_Pin GPIO_PIN_9
#define PC_TX_GPIO_Port GPIOA
#define PC_RX_Pin GPIO_PIN_10
#define PC_RX_GPIO_Port GPIOA
#define FLOW_PULSE_EXTI12_Pin GPIO_PIN_12
#define FLOW_PULSE_EXTI12_GPIO_Port GPIOA
#define LED1_Pin GPIO_PIN_12
#define LED1_GPIO_Port GPIOC
#define LED2_Pin GPIO_PIN_0
#define LED2_GPIO_Port GPIOD
#define ENCODER_A_Pin GPIO_PIN_1
#define ENCODER_A_GPIO_Port GPIOD
#define ENCODER_B_Pin GPIO_PIN_2
#define ENCODER_B_GPIO_Port GPIOD
#define ENCODER_SW_Pin GPIO_PIN_3
#define ENCODER_SW_GPIO_Port GPIOD
#define LCD_TX_Pin GPIO_PIN_5
#define LCD_TX_GPIO_Port GPIOD
#define LCD_RX_Pin GPIO_PIN_6
#define LCD_RX_GPIO_Port GPIOD
#define BEEP_OUT_Pin GPIO_PIN_4
#define BEEP_OUT_GPIO_Port GPIOB
#define EEPROM_WP_Pin GPIO_PIN_5
#define EEPROM_WP_GPIO_Port GPIOB
/* USER CODE END Private defines */

/* USER CODE BEGIN ET */


//-- For SysTick Flags
#define fSysTick_01MS 0x0001
#define fSysTick_05MS 0x0002
#define fSysTick_10MS 0x0004
#define fSysTick_20MS 0x0008
#define fSysTick_50MS 0x0010
#define fSysTick_500MS 0x0020
#define fSysTick_1000MS 0x0040


typedef struct
{
	uint16_t 	u16_SystemFlags;
	uint16_t 	u16_SysTickFlags;
	uint16_t 	u16_EncoderFlags;

	uint16_t	u16_Debounce_CNT;
	
} gv_InitTypeDef; /* Global Variable Type Definition */


#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
