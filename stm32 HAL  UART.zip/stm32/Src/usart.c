/**
  ******************************************************************************
  * File Name          : USART.c
  * Description        : This file provides code for the configuration
  *                      of the USART instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "usart.h"

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

UART_HandleTypeDef huart2;

/* USART2 init function */

void MX_USART2_UART_Init(void)
{

  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }

}

void HAL_UART_MspInit(UART_HandleTypeDef* uartHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(uartHandle->Instance==USART2)
  {
  /* USER CODE BEGIN USART2_MspInit 0 */

  /* USER CODE END USART2_MspInit 0 */
    /* USART2 clock enable */
    __HAL_RCC_USART2_CLK_ENABLE();
  
    __HAL_RCC_GPIOD_CLK_ENABLE();
    /**USART2 GPIO Configuration    
    PD5     ------> USART2_TX
    PD6     ------> USART2_RX 
    */
    GPIO_InitStruct.Pin = GPIO_PIN_5;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_6;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    __HAL_AFIO_REMAP_USART2_ENABLE();

    /* USART2 interrupt Init */
    HAL_NVIC_SetPriority(USART2_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(USART2_IRQn);
  /* USER CODE BEGIN USART2_MspInit 1 */

  /* USER CODE END USART2_MspInit 1 */
  }
}

void HAL_UART_MspDeInit(UART_HandleTypeDef* uartHandle)
{

  if(uartHandle->Instance==USART2)
  {
  /* USER CODE BEGIN USART2_MspDeInit 0 */

  /* USER CODE END USART2_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART2_CLK_DISABLE();
  
    /**USART2 GPIO Configuration    
    PD5     ------> USART2_TX
    PD6     ------> USART2_RX 
    */
    HAL_GPIO_DeInit(GPIOD, GPIO_PIN_5|GPIO_PIN_6);

    /* USART2 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART2_IRQn);
  /* USER CODE BEGIN USART2_MspDeInit 1 */

  /* USER CODE END USART2_MspDeInit 1 */
  }
} 

/* USER CODE BEGIN 1 */
#define USART2_TBUFF_SIZE               100        
#define USART2_RBUFF_SIZE               100  

static uint8_t Usart2_TBuff[USART2_TBUFF_SIZE];
static uint8_t Usart2_RBuff[USART2_RBUFF_SIZE];
static uint8_t Usart2_Tx_Counter;

static uint8_t Usart2_Tx_Pointer;
static uint8_t Usart2_Rx_Pointer;
static uint8_t Usart2_ReceiveCompleted=0;
//�������ڽ���
static void Start_Usart2_Receive(void)
{
    Usart2_Rx_Pointer =0;
		__HAL_UART_ENABLE_IT(&huart2, UART_IT_IDLE);			 //�����ж�
    __HAL_UART_ENABLE_IT(&huart2,UART_IT_RXNE);       //��������жϣ�ʹ��DMA�󽫱�����    
}

//�������ڷ���
static void Start_Usart2_Transmit(uint16_t num)
{
    Usart2_ReceiveCompleted=0;
    
    Usart2_Tx_Counter =num;
    Usart2_Tx_Pointer =0;
    
    USART2->DR=Usart2_TBuff [Usart2_Tx_Pointer];  //���͵�һ���ֽ�
		__HAL_UART_ENABLE_IT(&huart2,UART_IT_TC);     //�����ֽ����ж��з��� 
}

/*ҳ���л�
5A A5 04 80 03 0001
*/
void DWIN_PictureShow (uint16_t data)
{
    uint8_t *   frame;      //���ڻ���֡
    uint8_t     frame_len;
    uint16_t    crc;
    
    frame=(uint8_t *)Usart2_TBuff;
    frame_len=7;  //֡ͷ2B+����1B+����1B+��ַ1B+����2B+CRC 2B=9B 
    
    //֡ͷ�����ݳ���
    frame[0]=0X5a ;
    frame[1]=0xa5 ;
		frame[2]=frame_len -3;
		frame[3]=0x80;
		frame[4]=0x03 ;    
	
    frame[5]=data>>8;    //big endian
    frame[6]=data;	
	Start_Usart2_Transmit(frame_len );  //��ʼͨ��   

}

void USART2_IRQHandler(void)
{
    //�ڴ��ڿ����ж���
    if((USART2->SR)&USART_SR_IDLE)
    {
        USART2->DR ;		//��DR���ж�

				__HAL_UART_DISABLE_IT(&huart2, UART_IT_IDLE);			 //�����ж�ʧ��
				__HAL_UART_DISABLE_IT(&huart2,UART_IT_RXNE);       //��������ж�ʧ��			
		
        Usart2_ReceiveCompleted=1;
    }
    //�ڴ��ڷ�������ж���
    if((USART2->SR)&USART_SR_TC)
    {
        USART2->SR =~USART_SR_TC ; //д�����־

        Usart2_Tx_Counter --;
        if(Usart2_Tx_Counter!=0)
        {
            Usart2_Tx_Pointer++;
            USART2->DR=Usart2_TBuff [Usart2_Tx_Pointer];
        }
        else
        {
						__HAL_UART_DISABLE_IT(&huart2,UART_IT_TC);       //��������ж�ʧ��			
						
            Start_Usart2_Receive();
        }
    }    
    

    //�ڴ��ڽ�������ж���
    if((USART2->SR)&USART_SR_RXNE)
    {
    
        Usart2_RBuff [Usart2_Rx_Pointer ]=USART2->DR ;
        Usart2_Rx_Pointer++;
    } 
}

/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
