#ifndef __OS_FATS_H
#define __OS_FATS_H



#include "includes.h"



INT8U os_fats_init (void);




#endif

